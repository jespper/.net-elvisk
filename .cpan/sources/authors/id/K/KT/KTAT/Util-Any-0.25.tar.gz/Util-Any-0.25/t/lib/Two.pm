package Two;

use strict;
use warnings;

use One  qw(:ALL
             cpan_l2s);

1;

__END__

package MyUtilBase;

use Util::Any -Base;

our $Utils =
  {
   list => [['List::Util' => 'lu_']],
   error => ['Ktat::Ktat::Ktat'],
  };

1;

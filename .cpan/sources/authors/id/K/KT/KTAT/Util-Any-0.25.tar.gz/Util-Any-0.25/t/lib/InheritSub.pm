package InheritSub;

use strict;
use warnings;
use Inherit  qw(:ALL cpan_l2s);

1;

__END__
